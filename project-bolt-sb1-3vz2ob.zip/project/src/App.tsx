import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import LoginPage from './components/LoginPage';
import BusinessCard from './components/BusinessCard';
import PricingPlans from './components/PricingPlans';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<LoginPage />} />
        <Route path="/pricing" element={<PricingPlans />} />
        <Route path="/card" element={<BusinessCard />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;