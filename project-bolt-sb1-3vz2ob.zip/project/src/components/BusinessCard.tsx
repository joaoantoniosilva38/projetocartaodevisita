import React, { useState } from 'react';
import {
  Github,
  Linkedin,
  Globe,
  Mail,
  Download,
  Share2,
  Calendar,
  MessageSquare,
  ChevronDown,
  ChevronUp,
  MapPin,
  LogOut,
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function BusinessCard() {
  const [showBio, setShowBio] = useState(false);
  const [showPortfolio, setShowPortfolio] = useState(false);
  const navigate = useNavigate();

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'João Silva - Digital Business Card',
          text: 'Check out my digital business card!',
          url: window.location.href,
        });
      } catch (error) {
        console.log('Error sharing:', error);
      }
    }
  };

  const handleLogout = () => {
    navigate('/');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4 sm:p-8">
      <div className="max-w-2xl mx-auto relative">
        <button
          onClick={handleLogout}
          className="absolute top-4 right-4 p-2 rounded-full bg-white/80 hover:bg-white transition-colors z-10"
        >
          <LogOut className="w-5 h-5 text-gray-700" />
        </button>

        {/* Main Card */}
        <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
          {/* Header Image */}
          <div className="h-48 sm:h-64 overflow-hidden relative">
            <img
              src="https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?auto=format&fit=crop&w=800"
              alt="Cover"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
          </div>

          {/* Profile Section */}
          <div className="relative px-4 sm:px-6 pb-6">
            <div className="flex flex-col items-center -mt-16 sm:-mt-20">
              <img
                src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=200&h=200"
                alt="Profile"
                className="w-24 h-24 sm:w-32 sm:h-32 rounded-full border-4 border-white shadow-lg object-cover"
              />
              <h1 className="mt-4 text-2xl sm:text-3xl font-bold text-gray-800">João Silva</h1>
              <p className="text-gray-600 font-medium">Senior Web Developer</p>
              <div className="mt-4 flex gap-3">
                <button onClick={handleShare} className="p-2 rounded-full bg-gray-100 hover:bg-gray-200 transition-colors">
                  <Share2 className="w-5 h-5 text-gray-700" />
                </button>
                <a
                  href="/vcard.vcf"
                  download
                  className="p-2 rounded-full bg-gray-100 hover:bg-gray-200 transition-colors"
                >
                  <Download className="w-5 h-5 text-gray-700" />
                </a>
              </div>
            </div>

            {/* Contact Links */}
            <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 gap-4">
              <a
                href="mailto:joao@example.com"
                className="flex items-center justify-center gap-2 py-3 px-4 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 transition-colors"
              >
                <Mail className="w-5 h-5" />
                <span>Email Me</span>
              </a>
              <a
                href="#calendar"
                className="flex items-center justify-center gap-2 py-3 px-4 bg-gray-100 text-gray-700 rounded-xl hover:bg-gray-200 transition-colors"
              >
                <Calendar className="w-5 h-5" />
                <span>Schedule</span>
              </a>
            </div>

            {/* Bio Section */}
            <div className="mt-6">
              <button
                onClick={() => setShowBio(!showBio)}
                className="w-full flex items-center justify-between py-2 text-left"
              >
                <span className="text-lg font-semibold text-gray-800">About Me</span>
                {showBio ? (
                  <ChevronUp className="w-5 h-5 text-gray-600" />
                ) : (
                  <ChevronDown className="w-5 h-5 text-gray-600" />
                )}
              </button>
              {showBio && (
                <p className="mt-2 text-gray-600 leading-relaxed">
                  With over 10 years of experience in web development, I specialize in creating innovative
                  web applications and solutions. My expertise includes React, Node.js, and cloud
                  technologies, helping businesses transform their digital presence.
                </p>
              )}
            </div>

            {/* Portfolio Section */}
            <div className="mt-6">
              <button
                onClick={() => setShowPortfolio(!showPortfolio)}
                className="w-full flex items-center justify-between py-2 text-left"
              >
                <span className="text-lg font-semibold text-gray-800">Portfolio</span>
                {showPortfolio ? (
                  <ChevronUp className="w-5 h-5 text-gray-600" />
                ) : (
                  <ChevronDown className="w-5 h-5 text-gray-600" />
                )}
              </button>
              {showPortfolio && (
                <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="aspect-video rounded-lg overflow-hidden">
                    <img
                      src="https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=500"
                      alt="Project 1"
                      className="w-full h-full object-cover hover:scale-105 transition-transform"
                    />
                  </div>
                  <div className="aspect-video rounded-lg overflow-hidden">
                    <img
                      src="https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&w=500"
                      alt="Project 2"
                      className="w-full h-full object-cover hover:scale-105 transition-transform"
                    />
                  </div>
                </div>
              )}
            </div>

            {/* Social Links */}
            <div className="mt-8 flex flex-wrap justify-center gap-4">
              <a
                href="https://linkedin.com/in/joaosilva"
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 rounded-full bg-gray-100 hover:bg-gray-200 transition-colors"
              >
                <Linkedin className="w-5 h-5 text-gray-700" />
              </a>
              <a
                href="https://github.com/joaosilva"
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 rounded-full bg-gray-100 hover:bg-gray-200 transition-colors"
              >
                <Github className="w-5 h-5 text-gray-700" />
              </a>
              <a
                href="https://joaosilva.com"
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 rounded-full bg-gray-100 hover:bg-gray-200 transition-colors"
              >
                <Globe className="w-5 h-5 text-gray-700" />
              </a>
              <a
                href="#chat"
                className="p-2 rounded-full bg-gray-100 hover:bg-gray-200 transition-colors"
              >
                <MessageSquare className="w-5 h-5 text-gray-700" />
              </a>
              <a
                href="#location"
                className="p-2 rounded-full bg-gray-100 hover:bg-gray-200 transition-colors"
              >
                <MapPin className="w-5 h-5 text-gray-700" />
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}