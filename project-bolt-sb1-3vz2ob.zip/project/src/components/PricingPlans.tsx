import React from 'react';
import { Check, Star } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function PricingPlans() {
  const navigate = useNavigate();

  const handleSelectPlan = (plan: string) => {
    // Here you would implement the payment processing
    // For now, we'll just navigate to the card
    navigate('/card');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 py-12 px-4 sm:px-6">
      <div className="max-w-5xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Escolha seu plano</h1>
          <p className="text-xl text-gray-600">
            Selecione o plano ideal para suas necessidades
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {/* Plano Gratuito */}
          <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
            <div className="p-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Básico</h2>
              <p className="text-gray-600 mb-6">Perfeito para começar</p>
              <div className="flex items-baseline mb-8">
                <span className="text-4xl font-bold text-gray-900">R$ 0</span>
                <span className="text-gray-600 ml-2">/mês</span>
              </div>
              <button
                onClick={() => handleSelectPlan('basic')}
                className="w-full py-3 px-4 bg-gray-100 text-gray-700 rounded-xl hover:bg-gray-200 transition-colors font-medium"
              >
                Começar Grátis
              </button>
            </div>
            <div className="px-8 pb-8">
              <ul className="space-y-4">
                <li className="flex items-center gap-3">
                  <Check className="w-5 h-5 text-green-500" />
                  <span className="text-gray-600">Cartão digital básico</span>
                </li>
                <li className="flex items-center gap-3">
                  <Check className="w-5 h-5 text-green-500" />
                  <span className="text-gray-600">Compartilhamento via link</span>
                </li>
                <li className="flex items-center gap-3">
                  <Check className="w-5 h-5 text-green-500" />
                  <span className="text-gray-600">Informações de contato</span>
                </li>
              </ul>
            </div>
          </div>

          {/* Plano Profissional */}
          <div className="bg-white rounded-2xl shadow-lg overflow-hidden relative">
            <div className="absolute top-0 right-0 bg-indigo-600 text-white px-3 py-1 rounded-bl-lg">
              <div className="flex items-center gap-1">
                <Star className="w-4 h-4" />
                <span className="text-sm font-medium">Popular</span>
              </div>
            </div>
            <div className="p-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Profissional</h2>
              <p className="text-gray-600 mb-6">Para profissionais em crescimento</p>
              <div className="flex items-baseline mb-8">
                <span className="text-4xl font-bold text-gray-900">R$ 9,99</span>
                <span className="text-gray-600 ml-2">/mês</span>
              </div>
              <button
                onClick={() => handleSelectPlan('pro')}
                className="w-full py-3 px-4 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 transition-colors font-medium"
              >
                Começar Agora
              </button>
            </div>
            <div className="px-8 pb-8">
              <ul className="space-y-4">
                <li className="flex items-center gap-3">
                  <Check className="w-5 h-5 text-green-500" />
                  <span className="text-gray-600">Todas as funções do plano Básico</span>
                </li>
                <li className="flex items-center gap-3">
                  <Check className="w-5 h-5 text-green-500" />
                  <span className="text-gray-600">Portfólio personalizado</span>
                </li>
                <li className="flex items-center gap-3">
                  <Check className="w-5 h-5 text-green-500" />
                  <span className="text-gray-600">Análise de visitantes</span>
                </li>
                <li className="flex items-center gap-3">
                  <Check className="w-5 h-5 text-green-500" />
                  <span className="text-gray-600">Agendamento integrado</span>
                </li>
              </ul>
            </div>
          </div>

          {/* Plano Premium */}
          <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
            <div className="p-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Premium</h2>
              <p className="text-gray-600 mb-6">Para máximo desempenho</p>
              <div className="flex items-baseline mb-8">
                <span className="text-4xl font-bold text-gray-900">R$ 19,90</span>
                <span className="text-gray-600 ml-2">/mês</span>
              </div>
              <button
                onClick={() => handleSelectPlan('premium')}
                className="w-full py-3 px-4 bg-gray-900 text-white rounded-xl hover:bg-gray-800 transition-colors font-medium"
              >
                Começar Premium
              </button>
            </div>
            <div className="px-8 pb-8">
              <ul className="space-y-4">
                <li className="flex items-center gap-3">
                  <Check className="w-5 h-5 text-green-500" />
                  <span className="text-gray-600">Todas as funções do plano Profissional</span>
                </li>
                <li className="flex items-center gap-3">
                  <Check className="w-5 h-5 text-green-500" />
                  <span className="text-gray-600">Domínio personalizado</span>
                </li>
                <li className="flex items-center gap-3">
                  <Check className="w-5 h-5 text-green-500" />
                  <span className="text-gray-600">Suporte prioritário</span>
                </li>
                <li className="flex items-center gap-3">
                  <Check className="w-5 h-5 text-green-500" />
                  <span className="text-gray-600">Múltiplos cartões</span>
                </li>
                <li className="flex items-center gap-3">
                  <Check className="w-5 h-5 text-green-500" />
                  <span className="text-gray-600">Integrações avançadas</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}